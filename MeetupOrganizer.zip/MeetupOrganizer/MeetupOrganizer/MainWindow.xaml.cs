﻿using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Media.Imaging;

namespace MeetupOrganizer
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<ProgramItem> programItems;

        public MainWindow()
        {
            InitializeComponent();
            programItems = new ObservableCollection<ProgramItem>();
            ProgramItemsControl.ItemsSource = programItems;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Отмена: все поля будут очищены.");
            ClearFields();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            string details = $"Название: {TitleTextBox.Text}\n" +
                             $"Дата: {DatePicker.SelectedDate}\n" +
                             $"Место: {PlaceTextBox.Text}\n" +
                             $"Описание: {DescriptionTextBox.Text}\n" +
                             $"Количество пунктов программы: {programItems.Count}";
            MessageBox.Show(details);
        }

        private void AddProgramItem_Click(object sender, RoutedEventArgs e)
        {
            programItems.Add(new ProgramItem());
        }

        private void ClearFields()
        {
            TitleTextBox.Clear();
            DatePicker.SelectedDate = null;
            PlaceTextBox.Clear();
            DescriptionTextBox.Clear();
            programItems.Clear();
            ImagePreview.Source = null; // Очистка изображения
            RemoveImageButton.Visibility = Visibility.Collapsed; // Скрыть кнопку удаления
        }

        private void UploadImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp",
                Title = "Выберите изображение"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                BitmapImage bitmap = new BitmapImage(new Uri(openFileDialog.FileName));
                ImagePreview.Source = bitmap; // Установка загруженного изображения
                RemoveImageButton.Visibility = Visibility.Visible; // Показать кнопку удаления
            }
        }

        private void RemoveImageButton_Click(object sender, RoutedEventArgs e)
        {
            ImagePreview.Source = null; // Удаление изображения
            RemoveImageButton.Visibility = Visibility.Collapsed; // Скрытие кнопки удаления
        }
    }

    public class ProgramItem
    {
        public string Name { get; set; } = "Новый пункт";
        public TimeSpan StartsAt { get; set; }
        public TimeSpan EndsAt { get; set; }
    }
}